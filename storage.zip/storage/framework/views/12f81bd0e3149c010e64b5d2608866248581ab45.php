<?php $__env->startPush('pg_btn'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-user')): ?>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-neutral">Create New User</a>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-5">
                <div class="card-header bg-transparent">
                    <div class="row">
                        <div class="col-lg-8">
                            <h3 class="mb-0">Search History </h3>
                        </div>
                        <div class="col-lg-4">
                    <?php echo Form::open(['route' => 'history', 'method'=>'get']); ?>

                        <div class="form-group mb-0">
                        <?php echo e(Form::text('search', request()->query('search'), ['class' => 'form-control form-control-sm', 'placeholder'=>'Search Email'])); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <div>
                            <table class="table table-hover align-items-center">
                                <thead class="thead-light">
                                <tr>
                                    <th scope="col">SNO</th>
                                    <th scope="col">User Id</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">DB Name</th>
                                    <th scope="col">Search Key</th>
                                    <th scope="col">Search Value</th>
                                    <th scope="col">Created On</th>
                                </tr>
                                </thead>
                                <tbody class="list">
                                <?php $__currentLoopData = $historyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row">
                                            <?php echo e($history->id); ?>

                                        </th>
                                        <th scope="row">
                                            <?php echo e($history->user_id); ?>

                                        </th>
                                        <td class="budget">
                                            <?php echo e($history->email); ?>

                                        </td>
                                        <td class="budget">
                                            <?php echo e($history->db_name); ?>

                                        </td>
                                        <td class="budget">
                                            <?php echo e($history->search_key); ?>

                                        </td>
                                        <td class="budget">
                                            <?php echo e($history->search_value); ?>

                                        </td>
                                        <td class="budget">
                                            <?php echo e($history->created_at); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot >
                                <tr>
                                    <td colspan="6">
                                        <?php echo e($historyList->links()); ?>

                                    </td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www4\SQL Search2\resources\views/post/history.blade.php ENDPATH**/ ?>