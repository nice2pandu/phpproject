<select  name="db" id="searchByFilter" class="form-control" onchange="searchByFilterOption() ">
        <option value="">-- Select Filter --</option>
        <?php $__currentLoopData = $filtersDropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $databse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>"><?php echo e($databse); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


<?php /**PATH C:\www4\SQL Search2\resources\views/post/searchFilter.blade.php ENDPATH**/ ?>