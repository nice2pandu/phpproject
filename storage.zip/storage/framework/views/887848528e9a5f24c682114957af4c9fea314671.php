<?php $__env->startSection('content'); ?>

    <div class="form-row bg-primary1 backgroup-white" >
        <div class="col-md-12">
            <div class="card mb-3">
                <form id="search_form_data" action="<?php echo e(route('search')); ?>" method="POST">
                    <div class="card-header bg-transparent" id="search_form" style="padding:2px;">
                        <div class="form-row text-center d-flex justify-content-center">



                            <div class="col-md-2">
                                <select  name="db" id="dbName" class="form-control " onchange="doDBChange()">
                                    <option value="">--Select Database--</option>
                                    <?php $__currentLoopData = explode(',',env('DB_used')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $databse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($databse); ?>"><?php echo e($databse); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>









                            <div id="searchFilter"  class="col-md-3">


                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-outline-danger" value="Toggle Filters" onclick="oncleardata()"> <i class="fas fa-clean"></i> Clear Filters </button>
                            </div>



                        </div>
                    </div>
                </form>
            </div>
<!-- FILTERS START -->
       <div id="filters-div">
           <div class="row card-margin-12 text-center d-flex justify-content-center" id="searchByFilterOption">

           </div>
       </div>
            <!-- FILTERS END -->
            <div class="col-md-4" style="margin-left: auto;margin-right: auto">
                <div id="loader" class="lds-dual-ring hidden overlay"></div>
            </div>
        </div>


        <div class="dynamic_table" style="background-color: white;"></div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.4/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.print.min.js"></script>


    <script
        src="//cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/md5.js"></script>

    <script type="text/javascript">
        var table_datables = ''

        function toggleFilters()
        {
            $("#filters-div").toggle();
        }
        function doDBChange()
        {
            var db = $("#dbName").val();

            var url = "<?php echo e(route('searchFilter')); ?>"

            $.ajax({
                type: "POST",
                url: url,
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "db": db
                },
                success: function (data) {
                    $("#searchByFilterOption").html('');
                    $("#dynamic_table").html('');
                    $("#searchFilter").html(data);
                }
            });
            return false;
        }

        function searchByFilterOption()
        {
            var db = $("#dbName").val();
            var searchByFilter = $("#searchByFilter").val();
            var url = "<?php echo e(route('searchByFilterForm')); ?>"
            $.ajax({
                type: "POST",
                url: url,
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "db": db,
                    searchByFilter
                },
                success: function (data) {
                    $("#searchByFilterOption").html(data);
                }
            });
            return false;
        }

        function oncleardata() {
            url = "<?php echo e(route('search')); ?>"
            window.location.href = url

        }

        function searchData(searchType = 'FullSearch')
        {
            showCreditBalance();
             buildDataTable(searchType );

        }

        function buildDataTable( searchType)
        {
          //  console.log(formData);return false;
            var db = $("#dbName").val();
            var searchByFilter = $("#searchByFilter").val();

            var formData = $("#search-filter").serialize();
            var url = "<?php echo e(route('searchData')); ?>"
            //var form = $("#search_form_data");
var data = {
        "_token": "<?php echo e(csrf_token()); ?>",
        'formData'  : formData,
        "db": db,
        "searchByFilter" : searchByFilter,
    "searchType" : searchType
    };
       //     console.log(data);return false;
            $.ajax({
                type: "POST",
                url: url,
                data: data, // serializes the form's elements.
                beforeSend: function () { // Before we send the request, remove the .hidden class from the spinner and default to inline-block.
                    $('#loader').removeClass('hidden')
                },
                success: function (data) {
                    succData = JSON.parse(data)
                    if (succData['stop'] == true) {
                            alert("Recharge Your Credit Balance!");
                        // jQuery.confirm({
                        //     icon: 'fas fa-wind-warning',
                        //     closeIcon: true,
                        //     title: 'Are you sure Reload Blance!',
                        //     content: 'You can not undo this action.!!',
                        //     type: 'red',
                        //     typeAnimated: true,
                        //     buttons: {
                        //         cancel: function () {
                        //         }
                        //     }
                        // });
                            return false;
                    }
                    field_res = succData['res_arr'];

                    if (table_datables != '') {
                        table_datables.destroy();
                        $("#example").remove()
                    }
                    if (field_res.length != 0) {
                        $(".dynamic_table").append('<table id=\"example\" class=\"display\" style=\"width:100%\"></table>')

                        var my_columns = [];
                        $.each(field_res[0], function (key, value) {
                            var my_item = {};
                            my_item.data = key;
                            my_item.title = key;
                            my_columns.push(my_item);
                        });


                        table_datables = $('#example').DataTable({
                            dom: 'Bfrtip',
                            bProcessing: true,
                            data: field_res,
                            columns: my_columns,

                            buttons: [
                                 'csv', 'excel'
                            ],
                            columnDefs: [
                                {
                                    targets: -1,
                                    className: 'dt-body-right'
                                }
                            ],
                            error: function (jqXHR, textStatus, errorThrown) {
                                console.log(errorThrown)
                            }

                        });
                    }
                }, complete: function () { // Set our complete callback, adding the .hidden class and hiding the spinner.
                    $('#loader').addClass('hidden')
                },

            });
        return false;
            // $("#search_form_data").submit();
        }


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\www4\SQL Search2\resources\views/post/index2.blade.php ENDPATH**/ ?>