<nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom" style="padding-bottom: 0px;">
    <div class="container-fluid">
        <div class="navbar-header" id="navbarSupportedContent"></div>




















                    <div class="alert alert-warning alert-dismissible fade show " id="credit-box" style="margin: 0px;" role="alert">
                        <strong  >Your Credit Details!</strong>&nbsp;
                       <span class="badge badge-warning" id="usedCredits" style="font-size: larger">0</span>&nbsp;
                        <span class="badge badge-success" id="totalCredits"style="font-size: larger" >0</span>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>


                    <ul class="nav navbar-nav navbar-right">
                        <li class="nav-item dropdown">
                            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                               aria-expanded="false">
                                <div class="media align-items-center">
                              <span class="avatar avatar-sm rounded-circle">
                                <?php if(Auth::user()->profile_photo): ?>
                                      <img width="45" height="45" class="img-fluid rounded-pill"
                                           src="<?php echo e(asset(Auth::user()->profile_photo)); ?>" alt="">
                                  <?php else: ?>
                                      <i class="far avatar avatar-sm rounded-circle fa-user"></i>

                                  <?php endif; ?>
                              </span>
                                    <div class="media-body  ml-2  d-none d-lg-block">
                                        <span class="mb-0 text-sm  font-weight-bold"><?php echo e(Auth::user()->name); ?></span>
                                    </div>
                                </div>
                            </a>
                            <div class="dropdown-menu  dropdown-menu-right ">
                                <div class="dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome!</h6>
                                </div>
                                <a href="<?php echo e(route('profile.edit', auth()->user())); ?>" class="dropdown-item">
                                    <i class="ni ni-single-02"></i>
                                    <span>My profile</span>
                                </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span>Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    function showCreditBalance()
    {
        url = "<?php echo e(route('ajax-credits')); ?>";
        $.ajax({
            type: "GET",
            contentType: "application/json",
            url: url,
            data: {
                "_token": "<?php echo e(csrf_token()); ?>"
            },
            success: function (data) {
                var data = JSON.parse(data);
                if (data.usedCredits == data.totalCredits) {
                    $("#credit-box").html("Recharge your Credit Balance!");
                    $("#credit-box").addClass('text-danger');
                }
                $("#usedCredits").html( data.usedCredits);
                $("#totalCredits").html( data.totalCredits);
            },
            complete: function () { // Set our complete callback, adding the .hidden class and hiding the spinner.

            },
        });
    }
    // setInterval(function() {
    //     showCreditBalance();
    // }, 60 * 1000); //do call for 1 min
    showCreditBalance();
</script>

<?php $__env->stopPush(); ?>
<?php /**PATH C:\www\sql_v4\resources\views/includes/header.blade.php ENDPATH**/ ?>