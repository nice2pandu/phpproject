






<div class="form-group row">
    <label class="col-sm-6">Search By: </label>
    <div class="col-sm-10">
        <?php $__currentLoopData = $filtersDropdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $databse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadioOptions<?php echo e($key); ?>" value="<?php echo e($key); ?>" onchange="searchByFilterOption('<?php echo e($key); ?>') ">
            <label class="form-check-label" for="inlineRadio1"><?php echo e($databse); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>


<?php /**PATH C:\www\sql_v4\resources\views/post/searchFilter.blade.php ENDPATH**/ ?>